# Aster Home — smart-home software MVP

A responsive homeowner PWA and builder commissioning portal backed by a TypeScript API and PostgreSQL. Demo mode uses a clearly labelled simulator; no physical device is claimed to be connected.

## Stack
- Web: React, TypeScript, Vite, responsive PWA
- API: Node.js, Express, TypeScript, Prisma, PostgreSQL
- Security: Argon2 password hashing, JWT access tokens, Zod validation, rate limiting, tenant-scoped authorization and audit events
- Integrations: adapter contract with a deterministic simulator; future vendor/Home Assistant/MQTT adapters must use documented capabilities and trustworthy state reports

## Quick start
1. Install Node.js 20+ and PostgreSQL 15+.
2. Copy `apps/api/.env.example` to `apps/api/.env` and fill in local values. Copy `apps/web/.env.example` to `apps/web/.env` and set `VITE_API_BASE_URL=http://localhost:4000/api`. Never commit secrets.
3. From the repository root run `npm install`.
4. Run `npm run db:generate`, then `npm run db:migrate`.
5. Run `npm run seed` to create demo data (credentials are printed by the seed command only in local development).
6. In separate terminals run `npm run dev:api` and `npm run dev:web`.
7. Open the Vite URL. Use **Guided demo** for the simulator, or sign in using the local seeded account.

The web app runs in simulator demo mode without an API for rapid UX evaluation. Set `VITE_API_BASE_URL` to the API URL to enable the sign-in modal and persisted API-backed device commands, reminders and commissioning updates. The API refuses to start without required environment variables outside test mode.

## Environment variables
See `apps/api/.env.example` and `apps/web/.env.example`. Placeholders only; use a long random `JWT_SECRET` and rotate it if exposed.

## Tests and checks
- `npm test` runs API unit tests and web tests.
- `npm run build` builds both workspaces.
- `npm run db:migrate` applies versioned Prisma migrations.

## Deployment (low-cost pilot)
- Deploy the static `apps/web/dist` output to a static host with HTTPS.
- Deploy the API as one small Node service and PostgreSQL on a managed provider in the same region.
- Configure environment variables in the provider's secret store, not in source control.
- Set restrictive CORS, HTTPS-only cookies/tokens as applicable, backups, database connection limits, and monitoring before inviting real households.
- Run migrations as a release step. Keep simulator mode enabled until each real adapter passes device-specific integration tests.

## Safety and current limitations
- Simulator state is not physical state. The UI labels simulated data and distinguishes requested/pending state from confirmed state.
- No vendor-specific hardware APIs are bundled or invented. A future adapter must document supported commands, state freshness, offline behavior, and physical-switch semantics.
- Reminders in this MVP are app-level reminders, not certified safety controls. Do not use them as the sole protection against overheating, fire, water damage, or other hazards.
- Production rollout still requires security review, real-device integration tests, backup/restore drills, accessibility review, and an India-specific privacy/legal review.
