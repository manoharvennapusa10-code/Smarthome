import { describe,it,expect } from 'vitest';import { SimulatorAdapter } from './simulator.js';
const now=()=>new Date('2026-10-19T12:00:00.000Z');const adapter=new SimulatorAdapter(now);
describe('SimulatorAdapter',()=>{
 it('confirms a simulated command only when online',async()=>{const result=await adapter.command({externalId:'SIM-1',kind:'LIGHT',health:'ONLINE',state:{power:false}},{power:true});expect(result.status).toBe('confirmed');expect(result.report?.power).toBe(true);expect(result.report?.source).toBe('simulator');});
 it('does not send commands to offline devices',async()=>{const result=await adapter.command({externalId:'SIM-2',kind:'FAN',health:'OFFLINE',state:{power:true}},{power:false});expect(result.status).toBe('offline');expect(result.report).toBeUndefined();});
 it('does not claim state if offline',async()=>{const result=await adapter.readState({externalId:'SIM-2',kind:'FAN',health:'OFFLINE',state:{power:false}});expect(result.status).toBe('offline');expect(result.report).toBeUndefined();});
 it('rejects unsupported temperature values',async()=>{const result=await adapter.command({externalId:'SIM-3',kind:'AC',health:'ONLINE'},{temperatureC:80});expect(result.status).toBe('failed');});
});
