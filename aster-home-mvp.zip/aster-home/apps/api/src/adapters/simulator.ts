import type { AdapterDevice, AdapterResult, DeviceAdapter, DeviceCommand } from './types.js';

/** Deterministic, explicitly simulated adapter. Never contacts physical hardware. */
export class SimulatorAdapter implements DeviceAdapter {
  readonly key = 'simulator';
  constructor(private readonly now: () => Date = () => new Date()) {}
  async testConnection(device: AdapterDevice) {
    const online = device.health !== 'OFFLINE';
    return { online, checkedAt: this.now().toISOString(), detail: online ? 'Simulator endpoint responding' : 'Simulator device marked offline' };
  }
  async command(device: AdapterDevice, command: DeviceCommand): Promise<AdapterResult> {
    if (device.health !== 'ONLINE') return { status: 'offline', message: 'Device is offline; command was not sent.' };
    if (typeof command.power !== 'boolean' && command.temperatureC === undefined) return { status: 'failed', message: 'No supported command supplied.' };
    const report: Record<string, unknown> = { ...(device.state ?? {}) };
    if (typeof command.power === 'boolean') report.power = command.power;
    if (command.temperatureC !== undefined) {
      if (!Number.isFinite(command.temperatureC) || command.temperatureC < 16 || command.temperatureC > 30) return { status: 'failed', message: 'Temperature must be between 16 and 30 °C.' };
      report.temperatureC = command.temperatureC;
    }
    return { status: 'confirmed', report: { ...report, reportedAt: this.now().toISOString(), source: 'simulator' } };
  }
  async readState(device: AdapterDevice): Promise<AdapterResult> {
    if (device.health !== 'ONLINE') return { status: 'offline', message: 'State cannot be confirmed while the device is offline.' };
    if (!device.state) return { status: 'failed', message: 'No reported state available.' };
    return { status: 'confirmed', report: { ...device.state, reportedAt: this.now().toISOString(), source: 'simulator' } };
  }
}
