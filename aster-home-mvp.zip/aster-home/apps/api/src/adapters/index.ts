import { SimulatorAdapter } from './simulator.js';
import type { DeviceAdapter } from './types.js';

const adapters = new Map<string, DeviceAdapter>([['simulator', new SimulatorAdapter()]]);
export function getAdapter(key: string): DeviceAdapter {
  const adapter = adapters.get(key);
  if (!adapter) throw new Error(`Adapter '${key}' is not configured. No hardware command was sent.`);
  return adapter;
}
export function registerAdapter(adapter: DeviceAdapter): void { adapters.set(adapter.key, adapter); }
export function adapterKeys(): string[] { return [...adapters.keys()]; }
