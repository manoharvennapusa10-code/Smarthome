export type DeviceCommand = { power?: boolean; temperatureC?: number };
export type DeviceReport = { power?: boolean; temperatureC?: number; reportedAt: string; source: string };
export type AdapterResult = { status: 'confirmed' | 'pending' | 'failed' | 'offline'; report?: DeviceReport; message?: string };
export type AdapterDevice = { externalId: string; kind: string; health: 'ONLINE' | 'OFFLINE' | 'UNKNOWN'; state?: Record<string, unknown> | null };

/** All adapters must report what they can actually confirm; accepting a command is not confirmation. */
export interface DeviceAdapter {
  readonly key: string;
  testConnection(device: AdapterDevice): Promise<{ online: boolean; checkedAt: string; detail: string }>;
  command(device: AdapterDevice, command: DeviceCommand): Promise<AdapterResult>;
  readState(device: AdapterDevice): Promise<AdapterResult>;
}
