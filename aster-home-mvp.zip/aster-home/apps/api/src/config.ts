import 'dotenv/config';
import { z } from 'zod';
const schema = z.object({
 NODE_ENV: z.enum(['development','test','production']).default('development'),
 PORT: z.coerce.number().int().min(1).max(65535).default(4000),
 DATABASE_URL: z.string().min(1).optional(),
 JWT_SECRET: z.string().min(32).optional(),
 CORS_ORIGIN: z.string().url().default('http://localhost:5173'),
 ACCESS_TOKEN_TTL: z.string().default('15m'),
 SIMULATOR_ENABLED: z.enum(['true','false']).default('true')
});
const parsed = schema.safeParse(process.env);
if (!parsed.success) throw new Error(`Invalid environment configuration: ${parsed.error.issues.map(i=>i.path.join('.')+': '+i.message).join('; ')}`);
export const config = parsed.data;
if (config.NODE_ENV !== 'test' && (!config.DATABASE_URL || !config.JWT_SECRET)) throw new Error('DATABASE_URL and JWT_SECRET are required. Copy .env.example and set local secrets.');
export const jwtSecret = config.JWT_SECRET ?? 'test-only-secret-do-not-use-in-production';
