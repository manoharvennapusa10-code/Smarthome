import express from 'express';import cors from 'cors';import helmet from 'helmet';import rateLimit from 'express-rate-limit';
import { config } from './config.js';import { prisma } from './db.js';import { errorHandler,notFound } from './middleware/errors.js';
import authRoutes from './routes/auth.js';import homeRoutes from './routes/homes.js';import deviceRoutes from './routes/devices.js';import projectRoutes from './routes/projects.js';import reminderRoutes from './routes/reminders.js';import sceneRoutes from './routes/scenes.js';import commissioningRoutes from './routes/commissioning.js';
export const app=express();
app.disable('x-powered-by');app.use(helmet());app.use(cors({origin:config.CORS_ORIGIN,methods:['GET','POST','PATCH','DELETE'],allowedHeaders:['Content-Type','Authorization'],maxAge:600}));app.use(express.json({limit:'32kb',strict:true}));
app.use('/api',rateLimit({windowMs:60_000,limit:120,standardHeaders:true,legacyHeaders:false,message:{error:{code:'RATE_LIMITED',message:'Too many requests. Please retry shortly.'}}}));
app.get('/health',(_req,res)=>res.json({status:'ok',service:'aster-home-api',simulatorEnabled:config.SIMULATOR_ENABLED==='true'}));
app.use('/api/auth',rateLimit({windowMs:15*60_000,limit:10,standardHeaders:true,legacyHeaders:false}),authRoutes);
app.use('/api/homes',homeRoutes);app.use('/api/devices',deviceRoutes);app.use('/api/projects',projectRoutes);app.use('/api/reminders',reminderRoutes);app.use('/api/scenes',sceneRoutes);app.use('/api/commissioning',commissioningRoutes);app.use(notFound);app.use(errorHandler);
if(process.env.NODE_ENV!=='test') { const server=app.listen(config.PORT,()=>console.log(`Aster Home API listening on ${config.PORT}`)); const shutdown=async()=>{server.close();await prisma.$disconnect();};process.on('SIGINT',()=>void shutdown());process.on('SIGTERM',()=>void shutdown()); }
