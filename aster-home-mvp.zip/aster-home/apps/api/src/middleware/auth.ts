import type { NextFunction, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { jwtSecret } from '../config.js';
export type AuthUser = { sub: string; tenantId: string; role: 'PLATFORM_ADMIN'|'BUILDER'|'INSTALLER'|'HOMEOWNER' };
declare global { namespace Express { interface Request { auth?: AuthUser } } }
export function authenticate(req: Request,res: Response,next: NextFunction) {
 const header=req.header('authorization');
 if(!header?.startsWith('Bearer ')) return res.status(401).json({error:{code:'UNAUTHENTICATED',message:'Sign in to continue.'}});
 try { const payload=jwt.verify(header.slice(7),jwtSecret,{issuer:'aster-home'}); if(typeof payload==='string'||!('sub'in payload)||!('tenantId'in payload)||!('role'in payload)) throw new Error('invalid claims'); req.auth={sub:String(payload.sub),tenantId:String(payload.tenantId),role:payload.role as AuthUser['role']}; next(); }
 catch { return res.status(401).json({error:{code:'UNAUTHENTICATED',message:'Session is invalid or expired.'}}); }
}
export function allowRoles(...roles: AuthUser['role'][]) { return (req:Request,res:Response,next:NextFunction)=>{if(!req.auth)return res.status(401).json({error:{code:'UNAUTHENTICATED',message:'Sign in to continue.'}});if(!roles.includes(req.auth.role))return res.status(403).json({error:{code:'FORBIDDEN',message:'You do not have permission to perform this action.'}});next();}; }
