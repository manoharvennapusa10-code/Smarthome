import type { ErrorRequestHandler, RequestHandler } from 'express';
import { ZodError } from 'zod';
export const notFound: RequestHandler = (_req,res)=>res.status(404).json({error:{code:'NOT_FOUND',message:'The requested resource was not found.'}});
export const errorHandler: ErrorRequestHandler = (err,req,res,_next)=>{
 if(err instanceof ZodError) return res.status(400).json({error:{code:'VALIDATION_ERROR',message:'Please check the submitted fields.',details:err.issues.map(i=>({path:i.path.join('.'),message:i.message}))}});
 // Do not leak stack traces, database errors, tokens, or secrets to clients.
 console.error(JSON.stringify({level:'error',event:'request_failed',path:req.path,method:req.method,kind:err instanceof Error?err.name:'unknown'}));
 return res.status(500).json({error:{code:'INTERNAL_ERROR',message:'Something went wrong. Please try again.'}});
};
