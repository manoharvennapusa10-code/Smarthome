import 'dotenv/config';
import argon2 from 'argon2';
import { PrismaClient } from '@prisma/client';
const prisma=new PrismaClient();
async function main(){
 const tenant=await prisma.tenant.upsert({where:{id:'demo-builder'},update:{},create:{id:'demo-builder',name:'Willow Residential Demo'}});
 const email='demo@asterhome.local';const password=process.env.DEMO_PASSWORD||'ChangeThisDemoPassword!';
 const passwordHash=await argon2.hash(password);
 await prisma.user.upsert({where:{tenantId_email:{tenantId:tenant.id,email}},update:{passwordHash},create:{tenantId:tenant.id,email,name:'Demo Builder',passwordHash,role:'BUILDER'}});
 const project=await prisma.project.upsert({where:{id:'demo-project'},update:{},create:{id:'demo-project',tenantId:tenant.id,name:'Willow Residence',city:'Vijayawada',state:'Andhra Pradesh'}});
 const home=await prisma.home.upsert({where:{id:'demo-home'},update:{},create:{id:'demo-home',tenantId:tenant.id,projectId:project.id,name:'Willow Residence — 4B'}});
 const homeownerEmail='homeowner@asterhome.local';const homeownerPasswordHash=await argon2.hash(process.env.DEMO_HOMEOWNER_PASSWORD||'ChangeThisHomeownerPassword!');const homeowner=await prisma.user.upsert({where:{tenantId_email:{tenantId:tenant.id,email:homeownerEmail}},update:{passwordHash:homeownerPasswordHash},create:{tenantId:tenant.id,email:homeownerEmail,name:'Demo Homeowner',passwordHash:homeownerPasswordHash,role:'HOMEOWNER'}});await prisma.homeAccess.upsert({where:{userId_homeId:{userId:homeowner.id,homeId:home.id}},update:{},create:{userId:homeowner.id,homeId:home.id}});
 const roomNames=['Living room','Bedroom','Kitchen','Bathroom','Entry'];const roomIds:Record<string,string>={};
 for(const name of roomNames){const room=await prisma.room.upsert({where:{homeId_name:{homeId:home.id,name}},update:{},create:{homeId:home.id,name}});roomIds[name]=room.id;}
 const sample=[['SIM-LIV-01','Ceiling lights','LIGHT','Living room',true,'ONLINE'],['SIM-LIV-03','Air conditioner','AC','Living room',true,'ONLINE'],['SIM-KIT-01','Kitchen exhaust','FAN','Kitchen',false,'ONLINE'],['SIM-BED-01','Bedside lights','LIGHT','Bedroom',true,'ONLINE'],['SIM-BAT-01','Bathroom geyser','GEYSER','Bathroom',false,'ONLINE'],['SIM-BAT-02','Bathroom exhaust','FAN','Bathroom',false,'OFFLINE'],['SIM-ENT-01','Entry sensor','SENSOR','Entry',false,'ONLINE']] as const;
 for(const [externalId,name,kind,room,power,health] of sample){await prisma.device.upsert({where:{homeId_externalId:{homeId:home.id,externalId}},update:{},create:{homeId:home.id,roomId:roomIds[room]!,externalId,name,kind,adapterKey:'simulator',health,capabilities:kind==='SENSOR'?['presence']:['power'],reportedState:health==='ONLINE'?{power}:null,stateReportedAt:health==='ONLINE'?new Date():null}});}
 for(const title of ['Home and room structure reviewed','Device IDs assigned to rooms','Connection and command tests completed','Homeowner handover completed']) await prisma.commissioningItem.upsert({where:{homeId_title:{homeId:home.id,title}},update:{},create:{homeId:home.id,title,status:'PENDING'}});
 console.log('Seed complete. Local demo login:');console.log(`Tenant ID: ${tenant.id}`);console.log(`Email: ${email}`);console.log(`Password: ${password}`);console.log(`Homeowner email: ${homeownerEmail}`);console.log(`Homeowner password: ${process.env.DEMO_HOMEOWNER_PASSWORD||'ChangeThisHomeownerPassword!'}`);console.log('Change both demo passwords before sharing or deploying.');
}
main().catch(e=>{console.error(e);process.exitCode=1}).finally(()=>prisma.$disconnect());
