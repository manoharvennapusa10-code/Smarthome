import { describe,it,expect } from 'vitest';import { render,screen,fireEvent } from '@testing-library/react';import App from './App';
// UI smoke tests cover the guided demo and a user-visible control flow.
describe('Aster Home demo',()=>{
 it('labels sample data as simulated',()=>{render(<App/>);expect(screen.getByText(/live simulator/i)).toBeTruthy();expect(screen.getByText(/no physical devices are connected/i)).toBeTruthy();});
 it('navigates to devices and exposes offline state as unknown',()=>{render(<App/>);fireEvent.click(screen.getByRole('button',{name:'Devices'}));expect(screen.getByText('Your devices.')).toBeTruthy();expect(screen.getAllByText('Unknown').length).toBeGreaterThan(0);});
});
