# Device adapter contract

`DeviceAdapter` is the only integration boundary used by command/test flows. Implementations expose `testConnection`, `command`, and `readState` and return one of `confirmed`, `pending`, `failed`, or `offline`.

## Requirements for a real adapter

1. Use only documented vendor APIs or an officially supported Home Assistant/MQTT interface. Do not reverse-engineer or invent undocumented endpoints.
2. Keep credentials in the secret manager/environment; never return credentials in logs or device payloads.
3. Distinguish command acceptance from state confirmation. A successful HTTP/MQTT publish is `pending` until a trustworthy state report is received.
4. Set state freshness and offline semantics for each vendor. A stale last-known `power: false` must not be presented as a current confirmed off state.
5. Preserve the wall switch's local operation. Do not assume a cloud command or app timer overrides a physical switch.
6. Return `offline` if the device/gateway is unreachable and do not queue safety-sensitive commands silently.
7. Test reconnects, duplicate messages, retained MQTT messages, timeouts, out-of-order reports and manual-switch changes.

## Simulator

`SimulatorAdapter` is deterministic and in-process. It returns a `source: simulator` report when an online sample device accepts a supported command. It does not use network I/O and does not control physical hardware.

## MQTT / Home Assistant later

Add a new adapter module and register it with `registerAdapter()`. Store the adapter key and vendor-specific external ID in the `Device` mapping. Define documented capability metadata per model. Use an authenticated broker, TLS, least-privilege topics, message schema validation, retained-state freshness checks, and per-tenant gateway credentials. Never share one unrestricted broker credential across tenants.
