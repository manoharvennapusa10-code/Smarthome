# Security checklist before a real pilot

- [x] Password hashes use Argon2id via `argon2`.
- [x] Signed, short-lived access tokens; no token in URL.
- [x] Tenant ID is derived from verified token claims; data lookups scope home/project/device queries to that tenant.
- [x] Role checks on write/commissioning routes.
- [x] Zod request validation and bounded JSON body size.
- [x] Helmet, explicit CORS allow-origin and rate limits.
- [x] Generic client errors; server logs avoid request bodies and secrets.
- [x] Audit records for login, home/project/device mapping and confirmed commands.
- [ ] Add refresh-token rotation/revocation and session management before broad deployment.
- [ ] Add tenant-scoped integration tests against a disposable PostgreSQL database.
- [ ] Add IP hashing policy, retention/deletion policy and privacy notice before production.
- [ ] Enforce PostgreSQL row-level security or continue auditing every tenant-scoped query.
- [ ] Add encrypted secrets per tenant, backup/restore drills, vulnerability scanning and alerting.
- [ ] Complete India DPDP Act applicability review, terms, consent and data-processing agreements.
