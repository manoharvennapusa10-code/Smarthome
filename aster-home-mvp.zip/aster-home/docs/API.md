# API outline

All routes except `/health` and `POST /api/auth/login` require `Authorization: Bearer <accessToken>`.

- `POST /api/auth/login` — tenant ID, email, password; returns a short-lived bearer token.
- `GET /api/auth/me` — current account.
- `GET|POST /api/projects` — tenant-scoped builder projects.
- `GET|POST /api/homes`, `GET /api/homes/:homeId`, `POST /api/homes/:homeId/rooms` — homes and rooms.
- `GET|POST /api/devices`, `POST /api/devices/:deviceId/command`, `POST /api/devices/:deviceId/test` — mapping, commands and connection test.
- `GET|POST /api/reminders`, `PATCH /api/reminders/:id` — app-level reminders.
- `GET|POST /api/scenes`, `POST /api/scenes/:id/apply` — basic scene definitions; scene apply reports pending/offline rather than claiming atomic success.

Errors use `{ error: { code, message } }`. A command returns a confirmed report only when the adapter returns a trustworthy report. Simulator commands are explicitly labelled by `source: simulator`.
