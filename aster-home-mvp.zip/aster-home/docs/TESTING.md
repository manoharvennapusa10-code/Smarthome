# Test strategy

## Automated tests included

- `apps/api/src/adapters/simulator.test.ts`: confirmed simulator command, offline command rejection, offline state-read rejection, and range validation.
- `apps/web/src/App.test.tsx`: simulator labeling and navigation/device unknown-state smoke tests.

## Run locally

```sh
npm install
npm test
npm run build
```

For persistence and isolation verification, use a disposable PostgreSQL database, apply migrations, seed two tenants plus multiple homeowners, and assert that an unassigned homeowner receives `404` for another home's detail/device/reminder/scene. Exercise builder and installer roles separately. Do not use production customer data in test environments.

## Environment validation note

The development environment used to author this source had no installed workspace dependencies and could not reach the npm registry (`EAI_AGAIN`). The TypeScript/TSX files were syntax-transpiled with the globally available TypeScript compiler, and the service worker passed `node --check`; dependency-backed type checking, unit tests, Prisma validation, and production builds could not be completed here. Do not treat those checks as passing until run in a network-enabled environment with `npm install` completed.
